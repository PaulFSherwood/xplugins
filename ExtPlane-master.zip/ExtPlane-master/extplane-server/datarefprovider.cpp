#include "datarefprovider.h"

DataRefProvider::DataRefProvider() {}

DataRefProvider::~DataRefProvider() {}
