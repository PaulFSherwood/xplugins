#include "clientdatarefprovider.h"

ClientDataRefProvider::~ClientDataRefProvider() {}
