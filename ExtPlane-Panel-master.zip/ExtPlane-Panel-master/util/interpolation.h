#ifndef INTERPOLATION_H
#define INTERPOLATION_H

class Interpolation
{
public:
    static double linear(double x1, double x2, double y1, double y2, double x);
};

#endif // INTERPOLATION_H
